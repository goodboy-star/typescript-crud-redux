import React from 'react'

const User = () => {
    return (
        <>
            <div>
                hello, this is user
            </div>
        </>
    )
}

export default User