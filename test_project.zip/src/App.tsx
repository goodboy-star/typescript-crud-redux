import { useState } from "react";
// import hopsLogo from "/logo.png";
import Home from './Home'
import "./App.css";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <div className="container">
        <Home />
      </div>
      {/* <div>
        <a href="https://hopsworks.ai" target="_blank">
          <img src={hopsLogo} className="logo" alt="Hopsworks logo" />
        </a>
      </div>
      <h1>Case Frontend Engineer</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
      </div> */}
    </>
  );
}

export default App;
